package com.example.rtc

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley

class MainActivity : AppCompatActivity() {

    private val baseUrl = "http://192.168.70.149:5001"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val buttonLigar = findViewById<Button>(R.id.buttonLigar)
        val buttonDesligar = findViewById<Button>(R.id.buttonDesligar)

        buttonLigar.setOnClickListener {
            enviarComando("ligar_mobile", Request.Method.GET)
        }

        buttonDesligar.setOnClickListener {
            enviarComando("desligar_mobile", Request.Method.POST)
        }
    }

    private fun enviarComando(comando: String, method: Int) {
        val queue = Volley.newRequestQueue(this)
        val url = "$baseUrl/$comando"

        // Versão simplificada que corrige o erro de compilação.
        val stringRequest = StringRequest(method, url,
            { response ->
                Toast.makeText(this, "Sucesso: $response", Toast.LENGTH_SHORT).show()
            },
            { error ->
                val statusCode = error.networkResponse?.statusCode
                val errorMessage = when (error) {
                    is com.android.volley.NoConnectionError -> "FALHA DE CONEXÃO:\n- App não consegue alcançar a API.\n- Verifique se o IP ($baseUrl) está correto.\n- Verifique a regra do Firewall do Windows para a porta 5001."
                    is com.android.volley.TimeoutError -> "TEMPO ESGOTADO:\nA API demorou muito para responder."
                    is com.android.volley.ServerError -> "ERRO NO SERVIDOR (Cód: $statusCode):\nVerifique o terminal do VS Code."
                    is com.android.volley.NetworkError -> "ERRO DE REDE:\nVerifique a conexão Wi-Fi."
                    else -> "ERRO INESPERADO (Cód: $statusCode):\n${error.javaClass.simpleName}"
                }
                Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show()
            }
        )

        queue.add(stringRequest)
    }
}