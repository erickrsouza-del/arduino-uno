package com.example.rtc

import android.content.Context
import android.graphics.drawable.TransitionDrawable
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley

class MainActivity : AppCompatActivity() {

    private var baseUrl = ""
    private lateinit var buttonConectar: Button
    private lateinit var switchLed: SwitchCompat
    private lateinit var statusIcon: ImageView
    private lateinit var editTextIpAddress: EditText
    private lateinit var connectionGroup: LinearLayout
    private lateinit var controlsGroup: ConstraintLayout

    private var mediaPlayerOn: MediaPlayer? = null
    private var mediaPlayerOff: MediaPlayer? = null

    private val statusCheckHandler = Handler(Looper.getMainLooper())
    private lateinit var statusCheckRunnable: Runnable
    private var isConnected = false

    companion object {
        const val PREFS_NAME = "RTC_PREFS"
        const val PREF_LAST_IP = "LAST_IP"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializa as Views
        buttonConectar = findViewById(R.id.buttonConectar)
        switchLed = findViewById(R.id.switchLed)
        statusIcon = findViewById(R.id.statusIcon)
        editTextIpAddress = findViewById(R.id.editTextIpAddress)
        connectionGroup = findViewById(R.id.connectionGroup)
        controlsGroup = findViewById(R.id.controlsGroup)

        // Estilo inicial do botão
        buttonConectar.background = ContextCompat.getDrawable(this, R.drawable.button_background)

        // Carrega o último IP salvo
        loadLastIp()

        // Prepara os sons
        try {
            mediaPlayerOn = MediaPlayer.create(this, R.raw.ligar)
            mediaPlayerOff = MediaPlayer.create(this, R.raw.desligar)
        } catch (e: Exception) {
            // App não quebra se os sons não forem encontrados
        }

        // Listeners
        buttonConectar.setOnClickListener {
            conectar()
        }

        switchLed.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                enviarComando("ligar_mobile", Request.Method.GET)
                mediaPlayerOn?.start()
            } else {
                enviarComando("desligar_mobile", Request.Method.POST)
                mediaPlayerOff?.start()
            }
        }

        statusIcon.setOnClickListener {
            if (isConnected) {
                desconectarDaApi()
            }
        }

        setupStatusCheck()
    }

    private fun setupStatusCheck() {
        statusCheckRunnable = Runnable {
            if (isConnected) {
                verificarStatusDaApi()
            }
            statusCheckHandler.postDelayed(statusCheckRunnable, 5000) // Verifica a cada 5 segundos
        }
    }

    private fun conectar() {
        val ipAddress = editTextIpAddress.text.toString().trim()
        if (ipAddress.isEmpty()) {
            Toast.makeText(this, "Por favor, insira um endereço IP", Toast.LENGTH_SHORT).show()
            return
        }

        baseUrl = "http://$ipAddress:5001"

        val queue = Volley.newRequestQueue(this)
        val url = "$baseUrl/conectar"

        val transition = ContextCompat.getDrawable(this, R.drawable.button_color_animation) as TransitionDrawable
        buttonConectar.background = transition
        transition.startTransition(500)

        val stringRequest = StringRequest(Request.Method.POST, url,
            { response ->
                Handler(Looper.getMainLooper()).postDelayed({
                    Toast.makeText(this, "Conectado com sucesso!", Toast.LENGTH_SHORT).show()
                    isConnected = true
                    saveIpAddress(ipAddress)
                    mostrarControles(true)
                    statusCheckHandler.post(statusCheckRunnable)
                }, 600)
            },
            { error ->
                transition.reverseTransition(300)
                isConnected = false
                val errorMessage = when (error) {
                    is com.android.volley.NoConnectionError -> "FALHA DE CONEXÃO: Verifique o IP e a rede."
                    is com.android.volley.TimeoutError -> "TEMPO ESGOTADO: A API não respondeu."
                    else -> "ERRO (Cód: ${error.networkResponse?.statusCode}): Verifique a API."
                }
                Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show()
            }
        )
        queue.add(stringRequest)
    }

    private fun verificarStatusDaApi() {
        val queue = Volley.newRequestQueue(this)
        val url = "$baseUrl/status"

        val stringRequest = StringRequest(Request.Method.GET, url,
            { response ->
                if (!response.contains("conectado", ignoreCase = true)) {
                    retornarTelaInicial("A API se desconectou.")
                }
            },
            { error ->
                retornarTelaInicial("Conexão com a API perdida.")
            }
        )
        queue.add(stringRequest)
    }

    private fun desconectarDaApi() {
        val queue = Volley.newRequestQueue(this)
        val url = "$baseUrl/desconectar"

        val stringRequest = StringRequest(Request.Method.POST, url,
            { response ->
                retornarTelaInicial("Desconectado com sucesso.")
            },
            { error ->
                retornarTelaInicial("App desconectado.")
            }
        )
        queue.add(stringRequest)
    }

    private fun retornarTelaInicial(toastMessage: String) {
        isConnected = false
        statusCheckHandler.removeCallbacks(statusCheckRunnable)
        mostrarControles(false)
        Toast.makeText(this, toastMessage, Toast.LENGTH_SHORT).show()
        buttonConectar.background = ContextCompat.getDrawable(this, R.drawable.button_background)
    }

    private fun mostrarControles(mostrar: Boolean) {
        if (mostrar) {
            connectionGroup.visibility = View.GONE
            controlsGroup.visibility = View.VISIBLE
        } else {
            connectionGroup.visibility = View.VISIBLE
            controlsGroup.visibility = View.GONE
        }
        switchLed.isChecked = false
    }

    private fun enviarComando(comando: String, method: Int) {
        if (!isConnected) return
        val queue = Volley.newRequestQueue(this)
        val url = "$baseUrl/$comando"
        val stringRequest = StringRequest(method, url, { _ -> }, { _ ->
            verificarStatusDaApi()
        })
        queue.add(stringRequest)
    }

    private fun saveIpAddress(ip: String) {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(PREF_LAST_IP, ip).apply()
    }

    private fun loadLastIp() {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val lastIp = prefs.getString(PREF_LAST_IP, "")
        editTextIpAddress.setText(lastIp)
    }

    override fun onResume() {
        super.onResume()
        statusCheckHandler.post(statusCheckRunnable)
    }

    override fun onPause() {
        super.onPause()
        statusCheckHandler.removeCallbacks(statusCheckRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayerOn?.release()
        mediaPlayerOff?.release()
        statusCheckHandler.removeCallbacksAndMessages(null)
    }
}
