import threading
import time
import sqlite3
from datetime import datetime
from flask import Flask, render_template, jsonify
import serial
import serial.tools.list_ports

app = Flask(__name__)

# Configurações da porta serial
BAUD = 9600
DB_PATH = "led_status.db"

def detectar_porta():
    ports = list(serial.tools.list_ports.comports())
    print("--- PORTAS DISPONÍVEIS ---")
    for p in ports:
        print(f"{p.device} - {p.description}")
    
    if not ports:
        return None
        
    # Tenta preferir portas que não sejam padrão (COM1 costuma ser interna)
    for p in ports:
        if "COM1" not in p.device or len(ports) == 1:
            return p.device
            
    return ports[0].device

# Banco de dados SQLite
def inicializar_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS led_inteligente (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            descricao TEXT,
            data_hora TEXT,
            status TEXT
        )
    """)
    conn.commit()
    conn.close()

def salvar_led(descricao, data_hora, status):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("INSERT INTO led_inteligente (descricao, data_hora, status) VALUES (?, ?, ?)",
                (descricao, data_hora.isoformat(), status))
    conn.commit()
    conn.close()

def ultimos_registros(limit=50):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT descricao, data_hora, status FROM led_inteligente ORDER BY id DESC LIMIT ?", (limit,))
    rows = cur.fetchall()
    conn.close()
    return rows

# Gerenciador da porta serial
class SerialManager:
    def __init__(self):
        self.ser = None
        self.status = "Arduino Desconectado"
        self.rodando = False
        self.ultima_origem = None
        self.porta_atual = "COM3" # Fallback

    def conectar(self):
        try:
            nova_porta = detectar_porta()
            if nova_porta:
                self.porta_atual = nova_porta
                print(f"--- TENTANDO CONECTAR EM: {self.porta_atual} ---")
            else:
                self.status = "Nenhuma porta COM encontrada"
                return False

            self.ser = serial.Serial(self.porta_atual, BAUD, timeout=1)
            self.status = f"Conectado na {self.porta_atual}"
            self.rodando = True
            threading.Thread(target=self._ouvir, daemon=True).start()
            return True
        except serial.SerialException as e:
            if "PermissionError" in str(e) or "Acesso negado" in str(e):
                self.status = f"Porta {self.porta_atual} OCUPADA. Feche o Monitor Serial/IDE."
            else:
                self.status = f"Erro na {self.porta_atual}: {e}"
            return False
        except Exception as e:
            self.status = f"Falha genérica: {e}"
            return False

    def desconectar(self):
        self.rodando = False
        if self.ser:
            self.ser.close()
        self.status = "Arduino Desconectado"

    def enviar(self, comando, origem=None):
        self.ultima_origem = origem
        if not self.ser or not self.ser.is_open:
            return False, "Arduino Desconectado"
        try:
            if not comando.endswith("\n"):
                comando += "\n"
            self.ser.write(comando.encode())
            self.ser.flush()
            return True, "Comando enviado"
        except Exception as e:
            return False, f"Erro: {e}"

    def _ouvir(self):
        buffer = bytearray()
        while self.rodando:
            try:
                if self.ser.in_waiting > 0:
                    dados = self.ser.read(self.ser.in_waiting)
                    buffer.extend(dados)
                    while b"\n" in buffer:
                        linha, _, resto = buffer.partition(b"\n")
                        buffer = resto
                        msg = linha.decode().strip()
                        print(f"--- ARDUINO DIZ: {msg} ---") # Debug para ver no terminal
                        
                        self.status = msg
                        try:
                            # Tenta processar mensagens como "LED Ligado 27/01/2026 10:00:00"
                            partes = msg.split(" ", 2)
                            if len(partes) == 3:
                                prefixo, status, dataHora = partes
                                
                                # Limpeza básica do status (remove exclamação se houver)
                                status = status.replace("!", "")

                                # Lógica de origem (Mobile vs Web vs Botão)
                                if prefixo == "Led":
                                    descricao = "BOTAO"
                                    self.ultima_origem = None 
                                elif self.ultima_origem:
                                    descricao = self.ultima_origem
                                    self.ultima_origem = None
                                else:
                                    descricao = "LED" # Padrão (Web)
                                
                                # Tenta salvar. Se a data vier inválida (45/25...) ou mal formatada, usa fallback
                                try:
                                    try:
                                        dt = datetime.strptime(dataHora, "%d/%m/%Y %H:%M:%S")
                                    except ValueError:
                                        # Tenta corrigir formato sem zeros (ex: 1/1/2026 1:1:1)
                                        d, h = dataHora.split(' ')
                                        d_parts = [x.zfill(2) for x in d.split('/')]
                                        h_parts = [x.zfill(2) for x in h.split(':')]
                                        data_limpa = f"{'/'.join(d_parts)} {':'.join(h_parts)}"
                                        dt = datetime.strptime(data_limpa, "%d/%m/%Y %H:%M:%S")
                                except ValueError:
                                    # Se ainda assim falhar (datas absurdas tipo 45/25), usa hora do PC
                                    print(f"--- DATA INVÁLIDA ({dataHora}). USANDO DATA DO SISTEMA. ---")
                                    dt = datetime.now()

                                salvar_led(descricao, dt, status)
                                print(f"--- REGISTRO SALVO: {descricao} | {status} ---")

                        except Exception as e:
                            print(f"--- ERRO AO PROCESSAR LINHA: {e} ---")
                            pass
                time.sleep(0.05)
            except Exception as e:
                print(f"--- ERRO SERIAL: {e} ---")
                time.sleep(0.05)

serial_mgr = SerialManager()
inicializar_db()

# Rotas Flask   
@app.route("/")
def index():
    return render_template("index.html",
                           status=serial_mgr.status,
                           conectado=(serial_mgr.ser and serial_mgr.ser.is_open),
                           registros=ultimos_registros())

@app.route("/conectar", methods=["POST"])
def conectar():
    ok = serial_mgr.conectar()
    return jsonify({"ok": ok, "status": serial_mgr.status})

@app.route("/desconectar", methods=["POST"])
def desconectar():
    serial_mgr.desconectar()
    return jsonify({"ok": True, "status": serial_mgr.status})

@app.route("/ligar", methods=["POST","GET"])
def ligar():
    ok, msg = serial_mgr.enviar("ligar", origem="LED")
    return jsonify({"ok": ok, "msg": msg, "status": serial_mgr.status})

@app.route("/desligar", methods=["POST"])
def desligar():
    ok, msg = serial_mgr.enviar("desligar", origem="LED")
    return jsonify({"ok": ok, "msg": msg, "status": serial_mgr.status})

@app.route("/ligar_mobile", methods=["POST","GET"])
def ligar_mobile():
    ok, msg = serial_mgr.enviar("ligar", origem="SMARTPHONE")
    return jsonify({"ok": ok, "msg": msg, "status": serial_mgr.status})

@app.route("/desligar_mobile", methods=["POST","GET"])
def desligar_mobile():
    ok, msg = serial_mgr.enviar("desligar", origem="SMARTPHONE")
    return jsonify({"ok": ok, "msg": msg, "status": serial_mgr.status})

@app.route("/atualiza_datahora", methods=["POST"])
def atualiza_datahora():
    agora = datetime.now()
    comando = f"atualiza {agora.strftime('%y %m %d %H %M %S')}"
    ok, msg = serial_mgr.enviar(comando)
    return jsonify({"ok": ok, "msg": msg, "status": serial_mgr.status})

@app.route("/status")
def status():
    return jsonify({
        "status": serial_mgr.status,
        "conectado": (serial_mgr.ser and serial_mgr.ser.is_open),
        "registros": ultimos_registros()
    })

if __name__ == "__main__":
    try:
        app.run(debug=True, host="0.0.0.0", port=5001)
    finally:
        print("\n--- Encerrando servidor e liberando serial... ---")
        serial_mgr.desconectar()